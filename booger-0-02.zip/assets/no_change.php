<?php
/******************************************
* This file never changes with any upgrade
* This file is included in index.php before
* any output, so you can use it to start
* sessions or anything else that may fit
* your fancy
******************************************/
?>