editArea.add_lang("it",{
charmap_but: "Tastiera visuale",
charmap_title: "Tastiera visuale",
charmap_choose_block: "seleziona blocco",
charmap_insert:"inserisci questo carattere"
});
