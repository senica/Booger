<div class="footer-div-1 color-8"></div>
[global {'name':'footer'}]
<div class="footer-div-2 color-8"></div>
<div class="footer-div-3"></div>
<div class="clearfix"></div>
[sitefoot] <!-- This shortcode should remain here for plugins -->
</body>
</html>