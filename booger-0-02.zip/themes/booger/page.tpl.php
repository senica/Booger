<?php $bg->get_header(); ?>
<div id="header-separator"><div id="header-separator-shadow"></div></div>
<div id="content" class="color-3">
	[content {'class':'color-7 page-padding'}]
	<div class="clearfix"></div>
</div>
<?php $bg->get_footer(); ?>