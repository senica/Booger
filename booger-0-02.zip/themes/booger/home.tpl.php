<?php $bg->get_header(); ?>
<div id="header-separator"><div id="header-separator-shadow"></div></div>
<div id="content" class="color-3">
	<div class="home-content-1-wrapper">
		[home-title-1 {'class':'font-color-5 bold'}]
		[home-content-1 {'class':'font-color-7'}]
	</div>
	<div class="home-content-2-wrapper">
		<div class="home-download-border"></div>
		<div class="home-download">
			[home-content-2]
		</div>
		<div class="home-download-border"></div>
	</div>
	<div class="clearfix"></div>
	<div class="home-content-3-wrapper">
		[home-content-3]
		<div class="clearfix"></div>
	</div>
	[content]
	<div class="clearfix"></div>
</div>
<?php $bg->get_footer(); ?>