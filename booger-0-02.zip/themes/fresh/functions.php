<?php
$bg->add_shortcode('page-heading');	//Template Variable
$bg->add_shortcode('content');		//Template Variable
$bg->add_shortcode('sidebar');		//Template Variable
?>