<?php $bg->get_header(); ?>
<div class="body-wrapper">
	[page-heading]
	<div class="content-wrapper">
	[content]
	[comment-form]
	[comment-list]
	</div>
	<div class="sidebar-wrapper">
		[global {'name':'sidebar'}]
	</div>
</div>
<?php $bg->get_footer(); ?>