<div class="clearfix"></div>
<div class="footer-wrapper">
	<div class="col">
		<div class="title">[global {'name':'footer-title-1'}]</div>
		<div class="content">[global {'name':'footer-content-1'}]</div>
	</div>
	<div class="col">
		<div class="title">[global {'name':'footer-title-2'}]</div>
		<div class="content">[global {'name':'footer-content-2'}]</div>
	</div>
	<div class="col">
		<div class="title">[global {'name':'footer-title-3'}]</div>
		<div class="content">[global {'name':'footer-content-3'}]</div>
	</div>
</div>
<div class="clearfix"></div>
<div class="footer-close">
	[global {'name':'footer-close-content'}]
</div>
<?php $bg->call_hook('site-foot'); ?>
</body>
</html>