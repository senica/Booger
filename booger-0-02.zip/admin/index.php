<?php
	header("Location: ../index.php?bg_login=true");
?>